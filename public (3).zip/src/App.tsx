import "./App.css";
import EmployeeList from "./EmployList";

function App() {
  return (
    <>
      <EmployeeList />{" "}
    </>
  );
}

export default App;
